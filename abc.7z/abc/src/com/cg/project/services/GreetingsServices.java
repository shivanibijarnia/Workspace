package com.cg.project.services;

public interface GreetingsServices {
	void sayHello(String name);
	void sayGoodBye(String name);

}
