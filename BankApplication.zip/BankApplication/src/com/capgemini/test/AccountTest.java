package com.capgemini.test;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.InsufficientInitialAmountException;
import com.capgemini.exceptions.InvalidAccountNumberException;
import com.capgemini.model.Account;
import com.capgemini.repository.AccountRepository;
import com.capgemini.service.AccountService;
import com.capgemini.service.AccountServiceImpl;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
public class AccountTest {

	AccountService accountService;
	
	@Mock
	AccountRepository accountRepository;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		
		accountService = new AccountServiceImpl(accountRepository);
	}

	/*
	 * create account
	 * 1.when the amount is less than 500 then system should throw exception
	 * 2.when the valid info is passed account should be created successfully
	 * 
	 * deposit amount
	 * 1.when account number does not exist throw exception
	 * 2.when account exist deposit amount successfully
	 * 
	 * withdraw
	 * 1.when account number does not exist throw exception 
	 * 2.when account exist and amount to be withdraw is greater than min balance
	 * 3.when account exist and amount to be withdraw is less than min balance
	 */
	
	@Test(expected=com.capgemini.exceptions.InsufficientInitialAmountException.class)
	public void whenTheAmountIsLessThan500SystemShouldThrowException() throws InsufficientInitialAmountException
	{
		accountService.createAccount(101, 400);
	}
	
	@Test
	public void whenTheValidInfoIsPassedAccountShouldBeCreatedSuccessfully() throws InsufficientInitialAmountException
	{
		Account account =new Account();
		account.setAccountNumber(101);
		account.setAmount(5000);
		when(accountRepository.save(account)).thenReturn(true);
		assertEquals(account, accountService.createAccount(101, 5000));
	}
	
	@Test(expected=com.capgemini.exceptions.InvalidAccountNumberException.class)
	public void whenAccountnotExist() throws InvalidAccountNumberException
	{
		accountService.depositeAmount(111, 1000);		
	}	
	
	
	@Test
	public void whenAccountExist() throws InvalidAccountNumberException 
	{
		Account account2 =new Account();
		account2.setAccountNumber(102);
		account2.setAmount(4000);
		
		when(accountRepository.searchAccount(102)).thenReturn(account2);
		Account account1=accountService.depositeAmount(102, 1000);	
		System.out.println(account2);
		System.out.println(account1);
		assertEquals(account1, account2);
		
	}
	
	@Test(expected=com.capgemini.exceptions.InvalidAccountNumberException.class)
	public void whenAccountnotExistForWithdraw() throws InvalidAccountNumberException, InsufficientBalanceException
	{
		accountService.withdrawAmount(111, 1000);		
	}
	
	@Test
	public void whenAccountExistForWithdrawAndMinBalConditionIsSatisfy() throws InvalidAccountNumberException, InsufficientBalanceException
	{
		Account account2 =new Account();
		account2.setAccountNumber(103);
		account2.setAmount(4000);
		
		when(accountRepository.searchAccount(103)).thenReturn(account2);
		Account account1=accountService.withdrawAmount(103, 1000);	
		System.out.println(account2);
		System.out.println(account1);
		assertEquals(account1, account2);	
	}
	
	@Test(expected=com.capgemini.exceptions.InsufficientBalanceException.class)
	public void whenAccountExistForWithdrawAndMinBalConditionIsNotSatisfy() throws InvalidAccountNumberException, InsufficientBalanceException
	{
		Account account2 =new Account();
		account2.setAccountNumber(103);
		account2.setAmount(4000);
		
		when(accountRepository.searchAccount(103)).thenReturn(account2);
		Account account1=accountService.withdrawAmount(103, 4700);			
	}

}
